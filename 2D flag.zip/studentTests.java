import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Test;

import cmsc131_GridTools.RectangularGrid;
import student_Code.FlagMaker;

public class studentTests {

	@Test
	public void testSmallQ(){
		RectangularGrid grid = new RectangularGrid(2,2);
		grid.setColor(0, 0, Color.yellow);
		grid.setColor(0, 1, Color.yellow);
		grid.setColor(1, 0, Color.yellow);
		grid.setColor(1, 1, Color.yellow);
		
		RectangularGrid testGrid = new RectangularGrid(2,2);
		FlagMaker.drawQ(testGrid);
		assertEquals("grids are not the same", testGrid, grid);
	}
	
	@Test
	public void testSmallE(){
		RectangularGrid grid = new RectangularGrid(2,2);
		grid.setColor(0, 0, Color.blue);
		grid.setColor(0, 1, Color.blue);
		grid.setColor(1, 0, Color.red);
		grid.setColor(1, 1, Color.red);
		
		RectangularGrid testGrid = new RectangularGrid(2,2);
		FlagMaker.drawE(testGrid);
		assertEquals("grids are not the same", testGrid, grid);
	}
	
	@Test
	public void testSmallH() {
		RectangularGrid grid = new RectangularGrid(2,2);
		grid.setColor(0, 0, Color.white);
		grid.setColor(0, 1, Color.red);
		grid.setColor(1, 0, Color.white);
		grid.setColor(1, 1, Color.red);
		
		RectangularGrid testGrid = new RectangularGrid(2,2);
		FlagMaker.drawH(testGrid);
		assertEquals("grids are not the same", testGrid, grid);
	}
	
	@Test
	public void testSmallC() {
		RectangularGrid grid = new RectangularGrid(5,5);
		// first row and last row blue
		grid.setColor(0, 0, Color.blue);
		grid.setColor(0, 1, Color.blue);
		grid.setColor(0, 2, Color.blue);
		grid.setColor(0, 3, Color.blue);
		grid.setColor(0, 4, Color.blue);
		
		grid.setColor(4, 0, Color.blue);
		grid.setColor(4, 1, Color.blue);
		grid.setColor(4, 2, Color.blue);
		grid.setColor(4, 3, Color.blue);
		grid.setColor(4, 4, Color.blue);
		
		// second row and second to last row white
		grid.setColor(1, 0, Color.white);
		grid.setColor(1, 1, Color.white);
		grid.setColor(1, 2, Color.white);
		grid.setColor(1, 3, Color.white);
		grid.setColor(1, 4, Color.white);
		
		grid.setColor(3, 0, Color.white);
		grid.setColor(3, 1, Color.white);
		grid.setColor(3, 2, Color.white);
		grid.setColor(3, 3, Color.white);
		grid.setColor(3, 4, Color.white);		
		
		// middle row red
		grid.setColor(2, 0, Color.red);
		grid.setColor(2, 1, Color.red);
		grid.setColor(2, 2, Color.red);
		grid.setColor(2, 3, Color.red);
		grid.setColor(2, 4, Color.red);
		
		// now test the student code
		RectangularGrid testGrid = new RectangularGrid(5,5);
		FlagMaker.drawC(testGrid);
		assertEquals("grids are not the same", testGrid, grid);
	}
	
	@Test
	public void testSmallL()
	{
		RectangularGrid grid = new RectangularGrid(2,2);
	
		grid.setColor(0, 0, Color.yellow);
		grid.setColor(1, 1, Color.yellow);
		grid.setColor(0, 1, Color.black);
		grid.setColor(1, 0, Color.black);
		
		// now test the student code
		RectangularGrid testGrid = new RectangularGrid(2,2);
		FlagMaker.drawL(testGrid);
		assertEquals("grids are not the same", testGrid, grid);
	}
	
	@Test
	public void testSmallO()
	{
		RectangularGrid grid = new RectangularGrid(3,3);
	
		grid.setColor(0, 0, Color.red);
		grid.setColor(0, 1, Color.red);
		grid.setColor(0, 2, Color.red);
		grid.setColor(1, 0, Color.yellow);
		grid.setColor(1, 1, Color.red);
		grid.setColor(1, 2, Color.red);
		grid.setColor(2, 0, Color.yellow);
		grid.setColor(2, 1, Color.yellow);
		grid.setColor(2, 2, Color.red);
		
		// now test the student code
		RectangularGrid testGrid = new RectangularGrid(3,3);
		FlagMaker.drawO(testGrid);
		assertEquals("grids are not the same", testGrid, grid);		
	}
	
	@Test
	public void testSmallP()
	{
		RectangularGrid grid = new RectangularGrid(3,3);
		
		grid.setColor(0, 0, Color.blue);
		grid.setColor(0, 1, Color.blue);
		grid.setColor(0, 2, Color.blue);
		grid.setColor(1, 0, Color.blue);
		grid.setColor(1, 1, Color.white);
		grid.setColor(1, 2, Color.blue);
		grid.setColor(2, 0, Color.blue);
		grid.setColor(2, 1, Color.blue);
		grid.setColor(2, 2, Color.blue);
		
		// now test the student code
		RectangularGrid testGrid = new RectangularGrid(3,3);
		FlagMaker.drawP(testGrid);
		assertEquals("grids are not the same", testGrid, grid);		
	}
	
	@Test
	public void testSmallF()
	{
		RectangularGrid grid = new RectangularGrid(3,3);
		
		grid.setColor(0, 0, Color.white);
		grid.setColor(0, 1, Color.red);
		grid.setColor(0, 2, Color.white);
		grid.setColor(1, 0, Color.red);
		grid.setColor(1, 1, Color.red);
		grid.setColor(1, 2, Color.red);
		grid.setColor(2, 0, Color.white);
		grid.setColor(2, 1, Color.red);
		grid.setColor(2, 2, Color.white);
		
		// now test the student code
		RectangularGrid testGrid = new RectangularGrid(3,3);
		FlagMaker.drawF(testGrid);
		assertEquals("grids are not the same", testGrid, grid);			
	}
	
	@Test
	public void testCError()
	{
		RectangularGrid grid = new RectangularGrid (3, 2);
		grid.setColor(0, 0, Color.red);
		grid.setColor(0, 1, Color.red);
		grid.setColor(0, 2, Color.red);
		grid.setColor(1, 0, Color.red);
		grid.setColor(1, 1, Color.red);
		grid.setColor(1, 2, Color.red);	
		
		// now test the student code
		RectangularGrid testGrid = new RectangularGrid(3,2);
		FlagMaker.drawC(testGrid);
		assertEquals("grids are not the same", testGrid, grid);	
	}
	
	
}
