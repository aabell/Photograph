package cmsc131_GridTools;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.WindowConstants;
import java.awt.Color;

/**
 * WARNING: You should not be reading or changing this code!
 */

public class RectangularGrid extends JPanel {

	protected static final long serialVersionUID = 0L;
	protected static final int MARGIN_SIZE = 3;
	protected int internalHeight;
	protected int internalWidth;
	protected Color[][] colors;
	private static final int SQUARE_SIZE = 15;  //size of "pixel's" square
	private JFrame frame;

	protected RectangularGrid() {
	}

	/**
	 * Creates a new grid of given size
	 * 
	 * @param widthIn the width of the grid
	 * @param heightIn the height of the grid
	 */
	public RectangularGrid(int widthIn, int heightIn) {
		internalHeight = heightIn;
		internalWidth = widthIn;
		int overallSizeH = internalHeight + 2 * MARGIN_SIZE;
		int overallSizeW = internalWidth + 2 * MARGIN_SIZE;

		colors = new Color[overallSizeH][overallSizeW];
		for (int row=0; row<overallSizeH; row++) {
			for (int col=0; col<overallSizeW; col++) {
				colors[row][col] = Color.LIGHT_GRAY;
			}
		}

		//set the border/buffer 
		for (int row=0; row<overallSizeH; row++) {
			for (int col=0; col<MARGIN_SIZE; col++) {
				colors[row][col] = Color.GRAY;	
			}
			for (int col=overallSizeW-MARGIN_SIZE; col<overallSizeW; col++) {
				colors[row][col] = Color.GRAY;	
			}
		}

		for (int col=0; col<overallSizeW; col++) {
			for (int row=0; row<MARGIN_SIZE; row++) {
				colors[row][col] = Color.GRAY;	
			}
			for (int row=overallSizeH-MARGIN_SIZE; row<overallSizeH; row++) {
				colors[row][col] = Color.GRAY;	
			}
		}

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
				createAndShowFrame();
			}
		});	
	}
	
	/**
	 * @return returns the height of the grid
	 */
	public int getHt() {
		return internalHeight;
	}
	
	/**
	 * @return returns the width of the grid
	 */
	public int getWd(){
		return internalWidth;
	}

	private void createAndShowFrame() {
		frame = new JFrame("Drawing Grid");
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setSize((internalWidth + 2 * MARGIN_SIZE) * SQUARE_SIZE, 
				((internalHeight) + 2 * MARGIN_SIZE) * SQUARE_SIZE);
		frame.setContentPane(this);
		frame.pack();
		frame.setVisible(true);
		frame.toFront();
		frame.setAlwaysOnTop(true);
	}
    
	/**
	 * Sets the color of a given pixel to a given color
	 * 
	 * @param row row of the selected pixel
	 * @param col column of the selected pixel
	 * @param color Color object representing color to be assigned to pixel
	 * @throws IndexOutOfBoundsException if coordinates are out of bounds
	 * @see java.awt.Color
	 */
	public void setColor(int row, int col, Color color) {
	/*	if (row < 0 || col < 0 
			|| row >= internalHeight
			|| col >= internalWidth)
			throw (new IndexOutOfBoundsException("Position out of bounds"));
			*/
		colors[row + MARGIN_SIZE][col + MARGIN_SIZE] = color;
		this.repaint();
	}

	/**
	 * Retrieves the color of a given pixel
	 * 
	 * @param row row of pixel targeted
	 * @param col column of pixel targeted
	 * @return Color object representing the color of the chosen pixel
	 * @throws IndexOutOfBoundsException if coordinates are out of bounds
	 * @see java.awt.Color
	 */
	public Color getColor(int row, int col) {
	/*	if (row < 0 || col < 0 
				|| row >= internalHeight
				|| col >= internalWidth)
				throw (new IndexOutOfBoundsException("Position out of bounds"));
				*/

		return colors[row + MARGIN_SIZE][col + MARGIN_SIZE];
	}

	public void kill() {
		if (frame != null)
			frame.dispose();
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension((internalWidth + 2 * MARGIN_SIZE) * SQUARE_SIZE + 1, 
				((internalHeight) + 2 * MARGIN_SIZE) * SQUARE_SIZE + 1);
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);

		int offset = MARGIN_SIZE * SQUARE_SIZE;

		for (int row = 0; row < internalHeight + 2 * MARGIN_SIZE; row ++)
			for (int col = 0; col < internalWidth + 2 * MARGIN_SIZE; col++) {
				g.setColor(colors[row][col]);
				g.fillRect(col * SQUARE_SIZE + 1, row * SQUARE_SIZE + 1, 
						SQUARE_SIZE, SQUARE_SIZE);
			}

		//Draw the grid lines...
		g.setColor(Color.BLACK);
		for (int row = 0; row < internalWidth + 1; row++) 
			g.drawLine(offset + row * SQUARE_SIZE, offset, 
					offset + row * SQUARE_SIZE, offset + internalHeight * SQUARE_SIZE);
		for (int col = 0; col < internalHeight + 1; col++) 
			g.drawLine(offset, offset + col * SQUARE_SIZE, 
					offset + internalWidth * SQUARE_SIZE, offset + col * SQUARE_SIZE);
	}
	
	/**
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @param grid object of type RectangularGrid
	 * @return true if object contains the same color grid as the current object
	 */
	@Override
	public boolean equals(Object grid)
	{
		if (! (grid instanceof RectangularGrid))
			return false;
		
		if (grid == this)
			return true;
		
		RectangularGrid inGrid = (RectangularGrid) grid;
		
		if (inGrid.getHt() != internalHeight || inGrid.getWd() != internalWidth)
			return false;
		
		for (int row = 0; row < internalWidth; row++)
			for (int col = 0; col < internalHeight; col++)
				if (!(inGrid.getColor(row, col).equals(this.getColor(row, col))))
					return false;
		
		return true;
	}
	
	/**
	 * @see java.awt.Component#toString()
	 * @return string representation of grid with RGB color for each pixel
	 *         in hexadecimal format
	 */
	public String toString()
	{
		StringBuffer output = new StringBuffer(1 + (internalWidth * 9 + 1) * internalHeight);
		output.append('\n');
		for (int row = 0; row < internalWidth; row++) {
			for (int col = 0; col < internalHeight; col++)
				output.append(String.format("%x ", this.getColor(row, col).getRGB()));
			output.append('\n');
		}
		return output.toString();
	}
}
