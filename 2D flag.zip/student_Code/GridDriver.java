package student_Code;

import java.awt.Color;
import java.util.Scanner;
import cmsc131_GridTools.*;

public class GridDriver {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		char choice;
		int size;
		RectangularGrid grid;
		do {
			System.out.print("Please enter a letter between A and Z. To stop, enter the number 0: ");
			choice = input.next().toUpperCase().charAt(0);
			switch (choice){
			case '0' : break;
			case 'C' :
				System.out.print("Enter a size that is a multiple of 5: ");
				size = input.nextInt();
				grid = new RectangularGrid(size, size);
				launchStudentCode(grid, choice);
				break;	
			case 'Q' :
			case 'O' :
				System.out.print("Enter a grid size: ");
				size = input.nextInt();
				grid = new RectangularGrid(size, size);
				launchStudentCode(grid, choice);
				break;							
			case 'P' :
				System.out.print("Enter a size that is a multiple of 3: ");
				size = input.nextInt();
				grid = new RectangularGrid(size, size);
				launchStudentCode(grid, choice);
				break;				
			case 'N' :
				System.out.print("Enter a size that is a multiple of 4: ");
				size = input.nextInt();
				grid = new RectangularGrid(size, size);
				launchStudentCode(grid, choice);
				break;						
			case 'L' :
			case 'E' :
			case 'H' :
				System.out.print("Enter an even size: ");
				size = input.nextInt();
				grid = new RectangularGrid(size, size);
				launchStudentCode(grid, choice);
				break;
			case 'F' :
			case 'I' :
				System.out.print("Enter an odd size: ");
				size = input.nextInt();
				grid = new RectangularGrid(size, size);
				launchStudentCode(grid, choice);
				break;
			default :
				System.out.println("Flag '" + choice + "' not yet implemented. Try again!");
			}
		} while (choice != '0');
		input.close();
	}
	
	public static void launchStudentCode(RectangularGrid g, char flag){
		switch(flag){
		case 'Q':
			FlagMaker.drawQ(g);
			break;
		case 'E':
			FlagMaker.drawE(g);
			break;
		case 'H':
			FlagMaker.drawH(g);
			break;
		case 'L':
			FlagMaker.drawL(g);
			break;
		case 'C':
			FlagMaker.drawC(g);
			break;
		case 'O':
			FlagMaker.drawO(g);
			break;
		case 'P':
			FlagMaker.drawP(g);
			break;
		case 'F' :
			FlagMaker.drawF(g);
			break;
		case 'I' :
			FlagMaker.drawI(g);
			break;
		case 'N' :
			FlagMaker.drawN(g);
			break;
		default :
			throw(new IllegalArgumentException("Unknown flag"));
		}
	}

}
