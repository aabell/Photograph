package student_Code;

import cmsc131_GridTools.RectangularGrid; // The grid code

import java.awt.Color; // Java helps you draw colors

public class FlagMaker {
	/*
	 * Error flag - any flag that is all red
	 */
	public static void error(RectangularGrid grid)
	{
		// Your code goes here
		int x,y;
		x = grid.getHt();
		y = grid.getWd();
		 for (int row = 0; row < x; ++row)
		 {
		 	for (int col = 0; col < y; ++ col)
		 	{
		   grid.setColor (row, col, Color.RED);

		 	}
		 }
	}
		// Your code ends here
	
	
	
	/*
	 * Quebec flag
	 * 
	 * All yellow. 
	 * Grid must be square.
	 * Otherwise create red error flag
	 */
	public static void drawQ(RectangularGrid grid)
	{
		//  Your code goes  here
		int x = grid.getHt();
		 int y = grid.getWd();
		 for (int row = 0; row < x; ++row)
		 {
		 	for (int col = 0; col < y; ++ col)
		 	{
		   grid.setColor (row, col, Color.YELLOW);

		 	}
		 }
	}
		 
		//  Your code ends here
	
	

	/*
	 * Draw Echo flag
	 * 
	 * Split horizontally, blue on top, red on bottom
	 * 
	 * Grid must be square
	 * Side must be even-sized
	 * Otherwise create red error flag
	 */
	public static void drawE(RectangularGrid grid)
	{
		// Your code starts here
		int x,y;
		x = grid.getHt();
	    y = grid.getWd();
		if (x==y && x % 2==0)
		{
			x = grid.getHt();
			 y = grid.getWd();
			 for (int row = 0; row < x; ++row)
			 {
			 	for (int col = 0; col < y; ++ col)
			 	{
			   grid.setColor (row, col, Color.RED);

			 	}
			 }
			 for (int row = 0; row < x/2; ++row)
			 {
			 	for (int col = 0; col < y; ++col)
			 	{
			   grid.setColor (row, col, Color.BLUE);
			 	}
			 }
			 for (int row = 0; row < x/2; ++row)
			 {
			 	for (int col = 0; col < y; ++col)
			 	{
			   grid.setColor (row, col, Color.BLUE);
			 	}
			 }
			 for (int row = 0; row < x/2; ++row)
			 {
			 	for (int col = 0; col < y-(row+(x)); ++col)
			 	{
			   grid.setColor(row, col, Color.RED);
			 	}
			 }
			 for (int row = 0; row < x/2; ++row)
			 {
			 	for (int col = 0; col < (row/2)-4; ++col)
			 	{
			   grid.setColor (row, col, Color.RED);
			 	}	
			 }
		}
			 else{
				  x = grid.getHt();
				 y= grid.getWd();
				 for (int row = 0; row < x; ++row)
				 {
				 	for (int col = 0; col < y; ++ col)
				 	{
				   grid.setColor (row, col, Color.RED);

				 	}
				 }
			 }
		
		 
		 }
		// Your code ends here 
	
	
	/*
	 * Draw Hotel flag
	 * 
	 * Evenly split vertically, white and red
	 *
	 * Grid must be square
	 * Side must be even-sized
	 * Otherwise create red error flag
	 */
	public static void drawH(RectangularGrid grid)
	{
		// Your code start here
		int x,y;
		x = grid.getHt();
	    y = grid.getWd();
		if (x % 2==0)
		{
			for (int row = 0; row < y; ++row)
			 {
			 	for (int col = 0; col < y; ++ col)
			 	{
			   grid.setColor (row, col, Color.RED);

			 	}
			 }
			 for (int row = 0; row < x; ++row)
			 {
			 	for (int col = 0; col < y/2; ++col)
			 	{
			   grid.setColor (row, col, Color.WHITE);
			 	}
			 }
			 for (int row = 0; row < x; ++row)
			 {
			 	for (int col = 0; col < y/2; ++col)
			 	{
			   grid.setColor (row, col, Color.WHITE);
			 	}
			 }
			 for (int row = 0; row < x; ++row)
			 {
			 	for (int col = 0; col < y-(row+(x)); ++col)
			 	{
			   grid.setColor(row, col, Color.RED);
			 	}
			 }
			 for (int row = 0; row < x; ++row)
			 {
			 	for (int col = 0; col < row/2; ++col)
			 	{
			   grid.setColor (row, col, Color.WHITE);
			 	}
			 }
		}
		
		
		else{
			x = grid.getHt();
			 y = grid.getWd();
			 for (int row = 0; row < x; ++row)
			 {
			 	for (int col = 0; col < y; ++ col)
			 	{
			   grid.setColor (row, col, Color.RED);

			 	}
			 }
			 }
		}
		// Your code ends here
	
	
	/*
	 * Lima flag
	 * 
	 * Four squares, top left, bottom right are yellow, the rest black
	 * 
	 * Grid must be square
	 * Side must be even-sized
	 * Otherwise create red error flag
	 */
	public static void drawL(RectangularGrid grid)
	{
		// Your code start here
		int x,y;
		x = grid.getHt();
	    y = grid.getWd();
		if (x % 2==0){
			for (int row = 0; row < y; ++row)
			 {
			 	for (int col = 0; col < y; ++ col)
			 	{
			   grid.setColor (row, col, Color.YELLOW);

			 	}
			 }
			 
			 
			 for (int row =x/2; row < x; ++row)
			 {
			 	for (int col = 0; col < x/2; ++col)
			 	{
			   grid.setColor (row, col, Color.BLACK);
			 	}
			 }
		
			for (int row = 0; row < x/2; ++row)
			 {
			 	for (int col =y/2; col <y; ++col)
			 	{
			   grid.setColor(row,col,Color.BLACK);
			 	}
			 }
			}
			else{
				x = grid.getHt();
				 y = grid.getWd();
				 for (int row = 0; row < x; ++row)
				 {
				 	for (int col = 0; col < y; ++ col)
				 	{
				   grid.setColor (row, col, Color.RED);

				 	}
				 }
		
		
		
		}
		
		// Your code ends here
	}
	
	/*
	 * Draw Charlie flag
	 * 
	 *   5 horizontal bands:
	 *   blue, white, red, white, blue
	 *   
	 *   Grid must be square.
	 *   Side size must be multiple of 5
	 *   Otherwise create red error flag
	 */
	public static void drawC(RectangularGrid grid)
	{
		// Your code starts here
		int x,y;
		x = grid.getHt();
	    y = grid.getWd();
		if (x % 5==0){
	  for (int row = 0; row < x; ++row){
	if(row<grid.getHt()/5)
	for(int col=0;col<grid.getWd();col++)
	grid.setColor(row, col, Color.blue);
	else if(row<grid.getHt()/5*2)
	for(int col=0;col<grid.getWd();col++)
	grid.setColor(row, col, Color.white);
	else if(row<grid.getHt()/5*3)
	for(int col=0;col<grid.getWd();col++)
	grid.setColor(row, col, Color.red);
	else if(row<grid.getHt()/5*4)
	for(int col=0;col<grid.getWd();col++)
	grid.setColor(row, col, Color.white);
	else if(row<grid.getHt()/5*5)
	for(int col=0;col<grid.getWd();col++)
	grid.setColor(row, col, Color.blue);
			}
		}	else{
				x = grid.getHt();
				 y = grid.getWd();
				 for (int row = 0; row < x; ++row)
				 {
				 	for (int col = 0; col < y; ++ col)
				 	{
				   grid.setColor (row, col, Color.RED);

				 	}
				 }
		 }
	}
	
		// Your code ends here
	
	
	/*
	 * Oscar flag
	 * 
	 * diagonally split, top right red, bottom left yellow
	 * top left and bottom right corners must be red
	 * 
	 * Grid must be square
	 * Otherwise create red error flag
	 */
	public static void drawO(RectangularGrid grid)
	{
		// Your code starts here
		int x,y;
		 x = grid.getHt();
		 y = grid.getWd();
		 
		for (int row = 0; row < x; ++row)
		 {
		 	for (int col = 0; col < y; ++ col)
		 	{
		   grid.setColor (row, col, Color.red);

		 	}
		 }
		 for (int row = 0; row < x; ++row)
		 {
		 	for (int col = 0; col < row; ++col)
		 	{
		   grid.setColor (row, col, Color.yellow);
		 	}

		 }
		 
	}
		// Your code ends here
	
	
	/*
	 * Papa flag
	 * 
	 * Blue background with a white square in the middle.
	 * Inner square size is 1/3 of total size.
	 * 
	 * Grid must be square
	 * Size of sides must be multiple of three
	 * Otherwise create red error flag
	 */
	public static void drawP(RectangularGrid grid)
	{
		// Your code starts here
		
		
		 int x,y;
			x = grid.getHt();
		    y = grid.getWd();
			if (x % 3==0){
			for (int row = 0; row < y; ++row)
			{
			for (int col = 0; col < y; ++ col)
			{
		     grid.setColor (row, col, Color.blue);

				 	}
				 }
			for (int row = x/3; row < x*2/3; ++row){
					
			for(int col=y/3;col<y*2/3;col++)
			grid.setColor(row, col, Color.white);
					
				   
				}
			}
				else{
					x = grid.getHt();
					 y = grid.getWd();
					 for (int row = 0; row < x; ++row)
					 {
					 	for (int col = 0; col < y; ++ col)
					 	{
					   grid.setColor (row, col, Color.RED);

					 	}
					 }
			
			
			}
			}
			
		// Your code ends here

	
	/*
	 * Foxtrot flag
	 * 
	 * Red diamond on a white background
	 * 
	 * Grid must be a square
	 * Side must be odd-sized
	 * Otherwise create red error flag
	 */
	public static void drawF(RectangularGrid grid)
	//{
	// Your code starts here
		
		{
		 int h,w;
			h = grid.getHt();
		    w = grid.getWd();
			 
	if(h%2 != 0) 
			                { 
		for (int row = 0; row < h; ++row)
		 {
		 	for (int col = 0; col < w; ++ col)
		 	{
		   grid.setColor (row, col, Color.white);

		 	}
		 }
			                         
		 grid.setColor(0, grid.getHt()/2, Color.red); 
	     grid.setColor(grid.getHt()-1, grid.getHt()/2, Color.red); 
			                         
		int x = (grid.getWd()/2) - 1; 
	    int y = (grid.getWd()/2) + 1; 
		int shape = 1; 
		                       
		for (shape=1;shape<=grid.getHt()/2;)
	   { 
		int xy = x; 
		int yx = y; 
		int xxy = shape; 
	    for(; xy <= yx; xy++) 
	    grid.setColor(xxy, xy, Color.red); 
			                                 
		shape++; 
		x--; 
	    y++; 
	   } 
		                         
	x = 1; 
    y = grid.getWd() - 2; 
	shape = (grid.getHt()/2) + 1; 
	while(shape < grid.getHt()) 
	{ 
    int xy = x; 
    int yx = y; 
	int xxy = shape; 
	for(; xy <= yx; xy++) 
	 grid.setColor(xxy, xy, Color.red); 
			                                 
	shape++; 
	x++; 
	y--;    
			                        } 
			                }
	else{
		h = grid.getHt();
		 w = grid.getWd();
		 for (int row = 0; row < h; ++row)
		 {
		 	for (int col = 0; col < w; ++ col)
		 	{
		   grid.setColor (row, col, Color.RED);

		 	}
		 }
	}
		}
	
	


	
	
		private static int h() {
			// TODO Auto-generated method stub
			return 0;
		}
		// Your code ends here
	
	/*
	 * India flag
	 * 
	 * A black circle on a yellow background.
	 * 
	 * Circle diameter is floor(size / 2)
	 * 
	 * Grid must be square.
	 * Side must be odd-sized
	 * Otherwise create red error flag
	 */
	public static void drawI(RectangularGrid grid)
	{
		// Your code starts here
		
		// Your code ends here
	}
	
	/*
	 * November flag
	 * 
	 * Blue and white checkered 4x4 grid
	 * 
	 * Grid must be square
	 * Size of side must be multiple of 4
	 * Otherwise draw red error flag
	 */
	public static void drawN(RectangularGrid grid)
	{
		// Your code starts here
		
		// Your code ends here
	}
}
