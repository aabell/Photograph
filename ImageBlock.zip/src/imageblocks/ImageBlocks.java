
package imageblocks;

import java.awt.Color;
import java.util.*;

import utils.Picture;

public class ImageBlocks {
	static Color BLACK = new Color(0,0,0);
	static Color WHITE = new Color(255,255,255);                
	private int height;
	private int width;
	int [][] visited;
	Picture pic;


	private boolean isBlack(int x,int y){
		return pic.get(x,y).equals(BLACK);
	}
	private boolean isWhite(int x,int y){
		return pic.get(x,y).equals(WHITE);
	}
	/*
	 * input: file name if a black and white bitmap image.
	 * output: number of black blocks
	 */
	public int CountConnectedBlocks(String fileName){

		int count=0;
		this.pic =new Picture(fileName);
		this.height=pic.height();
		this.width=pic.width();

		this.visited = new int [width][height];
		
		for(int x=0;x<=width-1;x++){
			for(int y=0; y<=height-1;y++){
				if((visited[x][y]==0)&&isBlack(x,y))
				{
					count++;
					Travel1(x,y);			
				}
				
			}
		}
		return count;
	}

	public boolean sizeXY(int x, int y)
	{ 
		boolean checkx=x>=0 && x<=this.width-1;
		boolean checky=y>=0 && y<=this.height-1;
		return checkx&&checky;

	}
	private void Travel1(int x,int y)
	{

		if(sizeXY(x,y)&&isBlack(x,y)&&visited[x][y]==0)
		{
			visited[x][y]=1;
			Travel1(x+1,y+1);
			Travel1(x+1,y);
			Travel1(x+1,y-1);
			Travel1(x-1,y);
			Travel1(x,y-1);
			Travel1(x-1,y-1);
			Travel1(x-1,y+1);
			Travel1(x,y+1);
		}

	}
	
	public static void main(String[] args) {

		String fileName = "images/6.png";
		ImageBlocks block = new ImageBlocks();
		try{
			int c = block.CountConnectedBlocks(fileName);
			System.out.println("Number of connected blocks="+c);
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
}
