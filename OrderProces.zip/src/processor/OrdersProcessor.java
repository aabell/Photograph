package processor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.*;
public class OrdersProcessor {
	
	public static void main(String[] args) throws FileNotFoundException 
	{

		mainR rsultProcess=new mainR();
		rsultProcess.mainMathod();
		
	
	}

}

