package processor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class mainR 

{
	public BufferedWriter mainB;
	public HashMap<String, Double> price = new HashMap<String, Double>();
	public TreeMap<String, Integer> summary = new TreeMap<String, Integer>();
	public TreeMap<String, String> summarymap = new TreeMap<String, String>();

	public void createFile(String file)
	{
		try {
			mainB = new BufferedWriter(new FileWriter(file));
		} catch (IOException e) {
			e.printStackTrace();
			
		}
		
	}
	public synchronized void synchronized2(String name, String price)
	{
		summarymap.put(name, price);
	}
	public void itemsList(String file){
		try {
			BufferedReader result = new BufferedReader(new FileReader(file));

			for (Scanner set = new Scanner(new File(file)); set.hasNext();)
			{
			    String resultset = set.nextLine();
			    price.put(resultset.substring(0, resultset.indexOf(" ")), Double.parseDouble(resultset.substring(resultset.indexOf(" ")+1, resultset.length())));
			}
			
		} catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
	}
	public synchronized void synchronized1 (String name, int price)
	{
		summary.put(name, price);
	}
	//singleThread
	public void Thread1(String base, String name)
	{
		
		String result = "";
		FileWriter file;
		TreeMap<String, Integer> Identfication = new TreeMap<String, Integer>();
		try {
			Scanner set = new Scanner(new File(base));
			set.next();
			result = set.nextLine();
			result = result.substring(result.indexOf(" ")+1);
			
				for(;set.hasNext();){
					
				String curr = set.nextLine();
				curr = curr.substring(0, curr.indexOf(" "));
				
				if(!summary.containsKey(curr)){
					synchronized1(curr, 1);
				}
				else{
					synchronized1(curr, summary.get(curr)+1);
				}
				
				if(!Identfication.containsKey(curr)){
					Identfication.put(curr, 1);
				}
				else{
					Identfication.put(curr, Identfication.get(curr)+1);
				}
				}
		} catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		double orderTotal = 0.0;
		try {
			mainB.write("----- Order details for client with Id: " + result + " -----\n");
			for (Map.Entry<String, Integer> entry : Identfication.entrySet()){
				double costPerItem = price.get(entry.getKey());
				int quantity = entry.getValue();
				double cost = costPerItem*quantity;
				mainB.write("Item's name: " + entry.getKey() + ", "+"Cost per item: " +  NumberFormat.getCurrencyInstance().format(costPerItem) + ", "+
						"Quantity: " + quantity + ", "+"Cost: " + NumberFormat.getCurrencyInstance().format(cost) + "\n");
				      orderTotal += cost;
			}
			mainB.write("Order Total: " + NumberFormat.getCurrencyInstance().format(orderTotal));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
   public void summaryOrders(String file){
		double summaryTotal = 0.0;
		try {
			mainB.write("***** Summary of all orders *****\n");
			for (Map.Entry<String, Integer> entry : summary.entrySet()){
				double costPerItem = price.get(entry.getKey());
				int numSold = entry.getValue();
				double itemTotal = costPerItem*numSold;
				mainB.write("Summary - Item's name: " + entry.getKey() + ", "+"Cost per item: " +  NumberFormat.getCurrencyInstance().format(costPerItem) + ", "+
						"Number sold: " + numSold + ", "+"Item's Total: " + NumberFormat.getCurrencyInstance().format(itemTotal) + "\n");
				summaryTotal += itemTotal;
			}
			mainB.write("Summary Grand Total: " + NumberFormat.getCurrencyInstance().format(summaryTotal) + "\n");
			mainB.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	private class mainRunnable implements Runnable
	{
		String file, results;
		//
		public mainRunnable(String fileName, String resultsFileName)
		{
			file = fileName;
			results = resultsFileName;
		}
		@Override
		public void run() 
		{
			TreeMap<String, Integer> ListItem = new TreeMap<String, Integer>();
			String Id = "";
			FileWriter fileW;
			
			try {
				Scanner set = new Scanner(new File(file));
				set.next();
				Id = set.nextLine();
				Id = Id.substring(Id.indexOf(" ")+1);
				
				for(;set.hasNext();){
					String curr = set.nextLine();
					curr = curr.substring(0, curr.indexOf(" "));
					
					synchronized(summary){
					
						if(!summary.containsKey(curr)){
							synchronized1(curr, 1);
						}
						else{
							synchronized1(curr, summary.get(curr)+1);
						}
					}
					

					if(!ListItem.containsKey(curr)){
						ListItem.put(curr, 1);	
					}
					else
						ListItem.put(curr, ListItem.get(curr)+1);
					}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
			double orderClinet = 0.0;
			String orderList = "";			
			orderList += "----- Order details for client with Id: " + Id + " -----\n";
			for (Map.Entry<String, Integer> entry : ListItem.entrySet()){
				double costPerItem = price.get(entry.getKey());
				int quantity = entry.getValue();
				double cost = costPerItem*quantity;
				orderList += "Item's name: " + entry.getKey() + ", "+"Cost per item: " +  NumberFormat.getCurrencyInstance().format(costPerItem) 
						+ ", "+"Quantity: " + quantity + ", "+"Cost: " + NumberFormat.getCurrencyInstance().format(cost) + "\n";
				
				orderClinet += cost;
			}
			orderList += "Order Total: " + NumberFormat.getCurrencyInstance().format(orderClinet) + "\n";
			
			synchronized2(Id, orderList);
		}
	}
	
	public void mainMathod()
	{
		Scanner input = new Scanner(System.in);
		String fileName, typeOft, base, resultsName;
		int listOrders;
		
		System.out.print("Enter item's data file name: ");
		fileName = input.next();
		System.out.print("Enter 'y' for multiple threads, any other character otherwise: ");
		typeOft = input.next();
		System.out.print("Enter number of orders to process: ");
		listOrders = input.nextInt();
		System.out.print("Enter order's base filename: ");
		base = input.next();
		System.out.print("Enter result's filename: ");
		resultsName = input.next();
		System.out.println();
		//singel
		if(!typeOft.equalsIgnoreCase("y")){
			itemsList(fileName);
			createFile(resultsName);
			
			long startTime = System.currentTimeMillis();
			for(int i = 1; i <= listOrders; i++){
				Thread1(base + i + ".txt", resultsName);				
			}
			summaryOrders(resultsName);
			long endTime = System.currentTimeMillis();
			System.out.println("Processing time (msec): " + (endTime - startTime));
			//multi
		}else if(typeOft.equalsIgnoreCase("y")){
			itemsList(fileName);
			createFile(resultsName);
			
			ArrayList<Thread> threads = new ArrayList<Thread>();
			
			long startTime = System.currentTimeMillis();
			for(int i = 1; i <= listOrders; i++){
				//Thread t = new Thread();
				Thread t = new Thread(new mainRunnable(base + i + ".txt", resultsName));
				threads.add(t);
				t.start();				
			}
			for(Thread t: threads){
				try {
					t.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			for (Map.Entry<String, String> entry : summarymap.entrySet()){
				try {
					mainB.write(entry.getValue());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			summaryOrders(resultsName);
			long endTime = System.currentTimeMillis();
			System.out.println("Processing time (msec): " + (endTime - startTime));
		}
	}
	


}
