package processor;

public interface Runnabel {
public void run();
}
