package project7;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import project7.readCSV.*;

public class StatAnalysis {
	
	/***************************************************************
	 ** IMPORTANT - update line below to the file you plan to use **
	 ***************************************************************/
	public static final String FILE = "Traffic_Violations.csv";
	
	// BEGIN: class variables
	
	// END: class variables
	
	// BEGIN: required methods
	/**
	 * Populates the class variables by reading from a spreadsheet file in CSV format.
	 * @param name Name of the file containing the data.
	 */
	public void readData(String name){
		try {
			List<String>lines=Files.readAllLines(Paths.get(name));
			for (String line:lines){
				line=line.replace("\"","");
				
			    System.out.println(line);
				}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Computes the average of column i
	 * @param i column to be averaged
	 * @return average of the values in the column if column is numeric. If i is out of
	 *         range or column is not numerical it returns -1
	 */
	public double average(int col){
		
		try{
			List<String>lines=Files.readAllLines(Paths.get("Traffic_Violations.csv"));
			double sum=0,num=0,num1=0;
			for (String line:lines){
				if(num==0){
					++num;
					continue;
				}
				line=line.replace("\"","");
				String []result=line.split(",");
				double close = Double.parseDouble(result[col]);
				sum+=close;
				num1++;
			   }
			return (sum/num1);
		}catch(Exception e){
			return -1;
		}
	}
	/**
	 * Computes the median of the given column, i.e., the value such that
	 * half of the elements in the column are less than or equal to this value.
	 * 
	 * In other words, if you sorted the column in ascending order, the median
	 * is thevalue at location [nrow/2].
	 * 
	 * @param col column for which to compute the median
	 * @return median of given column if numeric.  Otherwise, or if index out of bounds, returns -1.
	 */
	public double median(int col) {
		ArrayList<Double> med=new ArrayList<Double>();
		try{
			List<String>lines=Files.readAllLines(Paths.get("Traffic_Violations.csv"));
			double sum=0,num=0;
			for (String line:lines){
				if(num==0){
					++num;
					continue;
				}
				line=line.replace("\"","");
				String []result=line.split(",");
				double close = Double.parseDouble(result[col]);
				med.add(close);
			    }
			
		}catch(Exception e){
			return -1;
		}
Collections.sort(med);
int l=med.size();
if(med.size()%2==1){
		return med.get(med.size()/2);
	}
	else{
		return med.get( ((med.size()/2)+((med.size()/2)+1))/2);
	}
	}
	
	
	
	/**
	 * Returns the mode (most frequent value) of the given column.
	 * @param col Column within which we compute mode.
	 * @return The mode of the column. Returns null if column index is out of range.
	 */
	public String mode(int col) {
		ArrayList<String> med=new ArrayList<String>();
try{
			List<String>lines=Files.readAllLines(Paths.get("Traffic_Violations.csv"));
             double num=0;
			for (String line:lines){
				if(num==0){
					++num;
					continue;
				}
				line=line.replace("\"","");
				String []result=line.split(",");
				med.add(result[col]);
			}
			int max=0;
			String maxcount="-1";
			
			for(int x =0;x<med.size();x++){
				int count=0;
				for (int y=0;y<med.size();y++){
					if (med.get(y).equals(med.get(x))){
						count++;
					}
						}
			if (count>max){
				maxcount=med.get(x);
				max=count;
			}
			}
			return maxcount;
		}catch(Exception e){
			return null;
		}

	}
	
	// END: required methods
	
	// BEGIN: Creative methods
	public void creative()
	{
		Map<String, Integer> Create = new HashMap<>();
	    
		try{
			List<String>lines=Files.readAllLines(Paths.get("Traffic_Violations.csv"));
			double sum=0,num=0,red=0;
			int cntr=0;
			for (String line:lines){
				if(num==0){
					++num;
					continue;
				}
				
				String []result=line.split(",");
				String Drive =result[5].toUpperCase();
				
				Integer cnt=Create.get(Drive);
				
				if (cnt==null){
					cnt=new Integer(0);
				}
				Create.put(Drive, ++cnt);
			    
			   
			}
			System.out.println("Acording to Traffic_Violation.csv the peopel who drive silver color car hava higher chance than the other"
					+ "color cars");
			System.out.println(Create);
			
		}catch(Exception e){
			System.out.println(e.getMessage());
			
		}
	}
	// END: Creative methods
	
	public static void main (String args[])
	{
		/*System.out.println(average(1));
		System.out.println(median(1));
		creative();
		System.out.println(mode(5));
		readData("Traffic_Violations.csv");*/
		
		StatAnalysis tot=new StatAnalysis();
		
		//tot.readData("Traffic_Violations.csv");
		//System.out.println(tot.average(1));
		//System.out.println(tot.median(0));
		//System.out.println(tot.mode(5));
	   tot.creative();
		
		// Use the main to try out the different methods
    // Also, write your own test cases to make sure your code works
	}
}
