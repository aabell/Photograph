/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sixdegrees;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;

public class SymbolGraph 
{
	private Graph G;
	private TreeMap<String, Integer>stringIndex;
	private TreeMap<Integer, String>stringIndex2;
	private int size=0;

	/**  
	 * Initializes a graph from a file using the specified delimiter.
	 * Each line in the file contains
	 * the name of a vertex, followed by a list of the names
	 * of the vertices adjacent to that vertex, separated by the delimiter.
	 * @param filename the name of the file
	 * @param delimiter the delimiter between fields
	 */
	public SymbolGraph(String filename, String delimiter) throws FileNotFoundException, IOException {
		stringIndex= new TreeMap<String,Integer>();
		stringIndex2=new TreeMap<Integer, String>();
		// First pass builds the index by reading strings to associate
		// distinct strings with an index
		BufferedReader reader = new BufferedReader(new FileReader(
				new File(filename)));
		// while (in.hasNextLine()) {
		String line;
		while ((line = reader.readLine()) != null) {    
			String[] data = line.split(delimiter);

			for (String s: data) {
				if(!stringIndex.containsKey(s))
				{
					stringIndex.put(s, size);
					stringIndex2.put(size, s);
					size++;

				}
  
			} 
		}
		System.out.println("Done reading " + filename);

		// second pass builds the graph by connecting first vertex on each
		// line to all others  
		G = new Graph(stringIndex.size());

		reader = new BufferedReader(new FileReader(
				new File(filename)));

		while ((line = reader.readLine()) != null) 
		{ 
			String[] data = line.split(delimiter);
			
			
			//find the movie 
			int vertixNumber=stringIndex.get(data[0]);
			int lineLength=data.length;
			//movies an actor
			for(int x=1;x<lineLength;x++)
			{
				int addE=stringIndex.get(data[x]);

				G.addEdge(vertixNumber, addE);
			}
		}



	}



	/**
	 * Does the graph contain the vertex named s
	 * @param s the name of a vertex
	 * @return true if s is the name of a vertex, and false otherwise
	 */
	public boolean contains(String s) {
		///return vertex name
		return stringIndex.containsKey(s);
		//return true;

	}

	/**
	 * return the adjacent vertices of a vertex named s
	 */
	public Bag<String> neighbors(String s){
		
		Bag<String> ls = new Bag();
		//get neighbor
		int neighborX=stringIndex.get(s);
		G.adj(neighborX);
		Iterable<Integer>intList=G.adj(neighborX);
		for(Integer y:intList)
		{
			//add neighbor
			ls.add(stringIndex2.get(y));
		}
		//return neighbor
		return ls;
	}
	/**
	 * return a list of movie title, actors, or actresses 
	 * if their names have s as a substring
	 */
	public Bag<String> list(String s){
		
		//creat HashMap
		Set<String>listBag=new HashSet<String>();
		Bag<String> ls = new Bag();
		//create new Set and get Key from TreeMap
		Set<String>listSet=stringIndex.keySet();
		for(String y: listSet){
			if(y.contains(s))
			{

				Bag<String>neighborsList=this.neighbors(y);
				for(String sub:neighborsList)
				{
					//add to new 
					listBag.add(sub);
				}
			}
			


		}
		for(String listSub:listBag){
			ls.add(listSub);
		}
		
		return ls;
	}
	/**
	 * Returns the integer associated with the vertex named s.
	 * @param s the name of a vertex
	 * @return the integer (between 0 and V - 1) associated with the vertex named s
	 */
	public int index(String s) {
		//return integer from the other TreeMap
		return stringIndex.get(s);

	}

	/**
	 * Returns the name of the vertex associated with the integer v.
	 * @param v the integer corresponding to a vertex (between 0 and V - 1) 
	 * @return the name of the vertex associated with the integer <tt>v</tt>
	 */
	public String name(int v) {
		

        //return name from TreeMap
		return stringIndex2.get(v);
	}

	/**
	 * Returns the graph associated with the symbol graph. It is the client's responsibility
	 * not to mutate the graph.
	 * @return the graph associated with the symbol graph
	 */
	public Graph G() {
		return G;
	}
}