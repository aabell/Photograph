package loopbag;

import java.util.Iterator;
  
public class Bag<E> implements LoopBag<E>{
	private int capacity;
	private E []bag;
	//Pradeep, Abel, Eiesus
    private int size;

	/**
	 * 
	 * @param capacity Fixed size bag capacity
	 */
public Bag(int capacity){
		
		this.capacity = capacity;
		bag = (E[]) new Object[capacity];
	}
	
	@Override
	public void insert(E item) {
		if(size<capacity){
			bag[size]=item;
			size++;
		}else{
			for(int i=0; i<capacity-1; i++){
				bag[i]=bag[i+1];
			}
			bag[capacity-1]=item;
			size=capacity;
			
		}
	}

	@Override
	public int size() {
		     
		return size;
	}

	@Override
	public boolean isEmpty() {
		
	 if(size()==0)
		 return true;
	 else
		 return false;
	}

	@Override
	public boolean contains(E item) {
		if(size != 0){
			for(int i = 0; i<size ; i++){
				if(bag[i] == item){
					return true;
				}
			}
		}
		return false;
	}
	

	@Override
	public void union(LoopBag<E> lb) {
		for(int i=0; i<lb.size(); i++){
			if(!(this.contains(lb.getIndex(i)))){
				
				insert(lb.getIndex(i));
			}
		}
	}
		
	

	@Override
	public Iterator<E> iterator() {
		return new BagIterator();

}

public String toString(){
	String str="";
	for(int i=0;i<size;i++){
		str +=bag[i]+",";
	}
	return str;
}

public E getIndex(int i){
	return bag[i];
}


private class BagIterator implements Iterator<E>{
	private int index = 0;
	
	@Override
	public boolean hasNext() {
		
		return index < size;
	}

	@Override
	public E next() {
		return bag[index++];
	}
	
}
}