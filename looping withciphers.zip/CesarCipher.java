import java.util.Scanner;

public class CesarCipher {
	
	public static String encryptCesar(String text, int key)
	{
		String output = "";
		/*
		 * For this assignment you will have to write
		 * code that encrypts the string found in variable 'text'
		 * using Cesar's cipher with the key found in variable 'key'
		 * 
		 * You must write your output in the variable 'output' which
		 * has already been initialized for you above. Simply append
		 * characters to this string by using:
		 * 
		 * output = output + character; // BTW - this is very inefficient but more on that later
		 * 
		 * IMPORTANT: convert the input string to all upper case and
		 * return a string that is all upper case.
		 * 
		 * Some useful hints:
		 *  - characters can be 'incremented', giving you the lexicographically
		 *  next character.  For example:
		 *  char c = 'A';
		 *  c++; // now c is 'B'
		 *  c += 4; // now c is 'E'
		 */
		
		// YOUR CODE STARTS HERE
		int ccbc;
		char bcc;
		text = text.toUpperCase();
		for (int i=0; i<text.length(); ++i)
		{
			if(text.charAt(i)+key>90){
				ccbc=(text.charAt(i)+key)-26;
			}
			else{
				ccbc=(text.charAt(i)+key);
			}
		bcc=(char)ccbc;
		output=output+bcc;
		
		
		}
		// YOUR CODE ENDS HERE	
		return (output);
	}

	public static String decryptCesar(String text, int key)
	{
		String output = "";
		/*
		 * For this assignment you will have to write
		 * code that decrypts the string found in variable 'text'
		 * using Cesar's cipher with the key found in variable 'key'
		 * 
		 * You must write your output in the variable 'output' which
		 * has already been initialized for you above. Simply append
		 * characters to this string by using:
		 * 
		 * output = output + character; // BTW - this is very inefficient but more on that later
		 * 
		 * IMPORTANT: convert the input string to all upper case and
		 * return a string that is all upper case.
		 * 
		 * Some useful hints:
		 *  - characters can be 'incremented', giving you the lexicographically
		 *  next character.  For example:
		 *  char c = 'A';
		 *  c++; // now c is 'B'
		 *  c += 4; // now c is 'E'
		 */
		
		
		// YOUR CODE STARTS HERE
		int ccbc,bcc;
		char bccc;
		
		text=text.toUpperCase();
		
		for(int i=0;i<text.length(); ++i){
			bcc=((text.charAt(i)-key)-64);
			if(bcc<=0){
				ccbc=(90-(bcc*(-1))%26);
			}
			else{
				ccbc=((bcc%26)+64);
			}
		bccc=(char)ccbc;
		output=output+bccc;
		}
		
		
		

		// YOUR CODE ENDS HERE
		return (output);
	}

	/**** DO NOT MODIFY THE CODE BELOW *****/		
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter your text on one line, and an integer key on the second line");
		String text = input.nextLine();
		int key = input.nextInt();
		System.out.println("Do you want to encode or decode?");
		String choice = input.next();
		if (choice.toLowerCase().equals("encode")){
			System.out.println(encryptCesar(text, key % 26));
		} else if (choice.toLowerCase().equals("decode")){
			System.out.println(decryptCesar(text, key % 26));
		} else {
			System.out.println("Please only enter 'encode' or 'decode'");
		}
	}
}
