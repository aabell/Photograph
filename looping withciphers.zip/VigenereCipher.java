import java.util.Scanner;

public class VigenereCipher {
	
	public static String encryptVigenere(String text, String key){
		String output = "";
		/*
		 * For this assignment you will have to write
		 * code that encrypts the string found in variable 'text'
		 * using Vigenere's cipher with the key found in variable 'key'
		 * 
		 * You must write your output in the variable 'output' which
		 * has already been initialized for you above. Simply append
		 * characters to this string by using:
		 * 
		 * output = output + character; // BTW - this is very inefficient but more on that later
		 * 
		 * IMPORTANT: convert the input string to all upper case and
		 * return a string that is all upper case.
		 * 
		 * Some useful hints:
		 *  - characters can be 'incremented', giving you the lexicographically
		 *  next character.  For example:
		 *  char c = 'A';
		 *  c++; // now c is 'B'
		 *  c += 4; // now c is 'E'
		 */
		
		// YOUR CODE STARTS HERE
		
        text = text.toUpperCase();
        if (key.equals(""))
        {
        	
        }
        else {
        	
        
        for (int i = 0, m = 0; i < text.length(); ++i) 
        {
            char bcc = text.charAt(i);
            if (bcc < 'A' || bcc > 'Z');
            output += (char)((bcc + key.charAt(m) - 2 * 'A') % 26 + 'A');
            m = ++m % key.length();
        }
        }
		// YOUR CODE ENDS HERE	
		return (output);
	}

	public static String decryptVigenere(String text, String key){
		String output = "";
		/*
		 * For this assignment you will have to write
		 * code that encrypts the string found in variable 'text'
		 * using Vigenere's cipher with the key found in variable 'key'
		 * 
		 * You must write your output in the variable 'output' which
		 * has already been initialized for you above. Simply append
		 * characters to this string by using:
		 * 
		 * output = output + character; // BTW - this is very inefficient but more on that later
		 * 
		 * IMPORTANT: convert the input string to all upper case and
		 * return a string that is all upper case.
		 * 
		 * Some useful hints:
		 *  - characters can be 'incremented', giving you the lexicographically
		 *  next character.  For example:
		 *  char c = 'A';
		 *  c++; // now c is 'B'
		 *  c += 4; // now c is 'E'
		 */
		
		// YOUR CODE STARTS HERE
		
        text = text.toUpperCase();
        for (int i = 0, m = 0; i < text.length(); ++i) {
            char bcc = text.charAt(i);
            if (bcc < 'A' || bcc > 'Z');
            output += (char)((bcc - key.charAt(m) + 26) % 26 + 'A');
            m = ++m % key.length();
        }
		// YOUR CODE ENDS HERE
		return (output);
	}
	
	/**** DO NOT MODIFY THE CODE BELOW *****/	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter your text on one line, and a string key on the second line");
		String text = input.nextLine();
		String key = input.next();
		System.out.println("Do you want to encode or decode?");
		String choice = input.next();
		if (choice.toLowerCase().equals("encode")){
			System.out.println(encryptVigenere(text, key.toUpperCase()));
		} else if (choice.toLowerCase().equals("decode")){
			System.out.println(decryptVigenere(text, key.toUpperCase()));
		} else {
			System.out.println("Please only enter 'encode' or 'decode'");
		}
	}

}
