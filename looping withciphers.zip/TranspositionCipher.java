import java.util.Scanner;

public class TranspositionCipher {
	public static String encryptTransposition(String text, int key) {
		String output = "";
		
		// YOUR CODE STARTS HERE

		// YOUR CODE ENDS HERE
		return output;
	}
	
	public static String decryptTransposition(String text, int key) {
		String output = "";
		
		// YOUR CODE STARTS HERE

		// YOUR CODE ENDS HERE
		
		return output;
	}
	
	/**** DO NOT MODIFY THE CODE BELOW *****/		

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter your text on one line, and an integer key on the second line");
		String text = input.nextLine();
		int key = input.nextInt();
		System.out.println("Do you want to encode or decode?");
		String choice = input.next();
		if (choice.toLowerCase().equals("encode")){
			System.out.println(encryptTransposition(text, key % 26));
		} else if (choice.toLowerCase().equals("decode")){
			System.out.println(decryptTransposition(text, key % 26));
		} else {
			System.out.println("Please only enter 'encode' or 'decode'");
		}
	}
}

